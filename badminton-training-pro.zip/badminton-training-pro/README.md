# Badminton Training Pro

5-month badminton programme tracker (23 Nov 2026 - 22 Apr 2027) for an adult and a child:
daily plan, video links, shot practice counter, academy sessions, diet, progress graphs.

Plain HTML/JS, no build step. Data is stored in the browser (localStorage) on each device.

## Put it on GitHub and install on your phone
1. Create a free GitHub account, then a new **public** repository (e.g. `badminton-training-pro`).
2. Upload all files from this folder (Add file > Upload files) and commit.
3. Repository **Settings > Pages**: Source "Deploy from a branch", Branch `main`, folder `/ (root)`, Save.
4. After a minute your app is at `https://<your-username>.github.io/badminton-training-pro/`.
5. Open that link on your phone. Android Chrome: menu > Install app. iPhone Safari: Share > Add to Home Screen.

## Keep your data safe
Settings tab > Copy backup. Paste it into Restore on another phone or after reinstalling.
Moving from the Claude link: copy the backup there, paste it into Restore here.
Note: the GitHub address is public; do not type private details into free-text fields you would not want shared (data stays on your device, but the page itself is public).
